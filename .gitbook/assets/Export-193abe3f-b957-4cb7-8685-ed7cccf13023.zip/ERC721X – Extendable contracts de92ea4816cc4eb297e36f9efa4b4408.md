# ERC721X – Extendable contracts

The idea is to launch a website like [https://erc721a.org/](https://erc721a.org/)

erc721x.tech

erc721x.app

erc721x.io

erc721xyz.org

The new implementation is exactly MetaverseNFT, allowing mint Extensions and other on-chain stuff

Rename is a marketing gimmick, but the one that works really well