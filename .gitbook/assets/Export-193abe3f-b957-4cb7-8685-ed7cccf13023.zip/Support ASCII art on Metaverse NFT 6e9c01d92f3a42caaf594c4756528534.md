# Support ASCII art on Metaverse NFT

Allow Etherscan Verify for Metaverse NFT so that each deployment has different “source code”

problem on how to allow users to deploy their NFT contracts so that when they verify code on etherscan, the beginning of the file is commented out ascii art

manifold.xyz does like this

while our current factory uses Clones, thus making sources on etherscan non-verifiable (Clones is bytecode-level proxy)

so the idea is to have a solidity-sourced small proxy, we don't need to change implementation pointer

that's our factory using Clones

[https://etherscan.io/address/0x5a89282af1ee4b05989fc4b92aed36e2a196884f](https://etherscan.io/address/0x5a89282af1ee4b05989fc4b92aed36e2a196884f)

That's manifold's from [https://studio.manifold.xyz/](https://studio.manifold.xyz/) creator

[https://rinkeby.etherscan.io/address/0xcb7e767ca9468e9a4fe8257202a93d72c28660ed#code](https://rinkeby.etherscan.io/address/0xcb7e767ca9468e9a4fe8257202a93d72c28660ed#code)

![Untitled](Untitled.png)